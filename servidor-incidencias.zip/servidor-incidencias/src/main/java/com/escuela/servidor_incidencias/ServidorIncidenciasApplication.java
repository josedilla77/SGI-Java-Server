package com.escuela.servidor_incidencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServidorIncidenciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServidorIncidenciasApplication.class, args);
	}

}
