package com.escuela.servidor_incidencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServidorIncidenciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
